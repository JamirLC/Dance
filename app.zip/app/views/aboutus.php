<?php
include APP_DIR.'views/templates/header.php';

// Get the current page name to highlight the active link
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>

    <!-- FullCalendar CSS -->
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@3.10.2/dist/fullcalendar.min.css" rel="stylesheet" />

    <!-- Font Awesome for Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

    <style>
        /* General Styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f9fc;
            color: #333;
            margin: 0;
            padding: 0;
        }

        /* Main app container */
        #app {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styling */
        #sidebar {
            width: 300px;
            background-color: #fff; /* White background for the sidebar */
            color: #333;
            min-height: 200vh;
            border-right: 1px solid #ddd;
            padding: 20px 10px;
        }

        #sidebar .logo {
            text-align: center;
            margin-bottom: 50px;
        }

        #sidebar .logo img {
            max-width: 200px;
        }

        #sidebar ul {
            list-style: none;
            padding: 0;
        }

        #sidebar ul li {
            margin: 15px 0;
        }

        #sidebar ul li a {
            display: flex;
            align-items: center;
            color: #333; /* Dark text color */
            text-decoration: none;
            padding: 10px;
            border-radius: 5px;
            font-size: 18px;
            transition: background-color 0.3s, color 0.3s;
        }

        #sidebar ul li a .icon {
            margin-right: 10px; /* Spacing between icon and text */
            font-size: 20px; /* Icon size */
            color: #1E90FF; /* Blue color for icons */
        }

        #sidebar ul li a:hover, 
        #sidebar ul li a.active {
            background-color: #242582; /* Background on hover and active */
            color: #fff; /* White text on hover and active */
        }

        /* Main Content Styling */
        main {
            flex-grow: 1;
            padding: 20px;
            background-color: #f9fafb;
        }

        .container {
            padding-top: 20px;
        }

        h1#users-header {
            color: #242582;
            font-weight: 600;
            margin-bottom: 20px;
        }

        /* Card Styling */
        .card-header {
            background-color: #f64c72;
            color: #fff;
            font-weight: bold;
            font-size: 1.2rem;
            border-radius: 8px 8px 0 0;
        }

        .card-body {
            background-color: #fff;
            padding: 20px;
            border-radius: 0 0 8px 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        /* Flexbox for 10 boxes per line */
        .box-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px; /* Space between boxes */
        }

        .box {
            flex: 0 0 9.5%; /* Each box takes up 9.5% of the width to fit 10 per line */
            box-sizing: border-box;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 10px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .box img {
            width: 100%;
            height: auto;
            border-radius: 5px;
        }

        .view-button {
            margin-top: 10px;
            padding: 8px 16px;
            background-color: #242582;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .view-button:hover {
            background-color: #1E90FF;
        }

        /* Modal Styling */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0, 0, 0);
            background-color: rgba(0, 0, 0, 0.4);
        }

        .modal-content {
            background-color: #fff;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 600px;
            border-radius: 8px;
        }

        .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 10px;
            right: 25px;
            transition: 0.3s;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

    </style>
</head>
<body>
    <div id="app">
        <!-- Sidebar -->
        <nav id="sidebar">
            <div class="logo">
                <img src="/public/image/dance.png" alt="Dance Studio Logo">
            </div>
            <ul>
                <!-- Dashboard Link -->
                <li>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link <?= ($current_page == 'dashboard.php') ? 'active' : ''; ?>" href="/home">
                                <span class="icon">&#127968;</span> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= ($current_page == 'classes.php') ? 'active' : ''; ?>" href="/classes">
                                <span class="icon">&#128218;</span> Classes
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= ($current_page == 'appointments.php') ? 'active' : ''; ?>" href="/appointments">
                                <span class="icon">&#128197;</span> Scheduling
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= ($current_page == 'aboutus.php') ? 'active' : ''; ?>" href="/about-us">
                                <span class="icon">&#8505;</span> About Us
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>

        <!-- Main Content -->
        <main>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">About Us</div>
                            <div class="card-body">
                                <h2>Welcome to our Dance Studio!</h2>
                                <p>Welcome to our Dance Studio, where passion meets movement! Our studio offers a welcoming environment for dancers of all levels...</p>
                                
                                <!-- Box Container with 10 Boxes per Row -->
                                <div class="box-container">
                                    <?php for ($i = 1; $i <= 20; $i++): ?>
                                    <div class="box">
                                        <img src="https://via.placeholder.com/150" alt="Image <?php echo $i; ?>">
                                        <button class="view-button" onclick="showModal(<?php echo $i; ?>)">View</button>
                                    </div>
                                    <?php endfor; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Modal for Displaying Information -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2 id="modalTitle">Dance Information</h2>
            <p id="modalBody">Details about the dance...</p>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@3.10.2/dist/fullcalendar.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>

    <script>
        // Open the modal when "View" button is clicked
        function showModal(boxNumber) {
            // Sample information about the dances (you can replace this with actual data)
            const danceInfo = [
                'Salsa: A lively dance with Latin rhythms.',
                'Ballet: A classical dance form known for its graceful movements.',
                'Hip Hop: A street dance that emerged from hip hop culture.',
                // Add more information here for other dances
            ];

            // Set the modal content
            document.getElementById('modalTitle').innerText = 'Dance Information ' + boxNumber;
            document.getElementById('modalBody').innerText = danceInfo[boxNumber % danceInfo.length];

            // Show the modal
            document.getElementById('myModal').style.display = 'block';
        }

        // Close the modal when the "X" button is clicked
        document.querySelector('.close').onclick = function() {
            document.getElementById('myModal').style.display = 'none';
        }

        // Close the modal when the user clicks outside of the modal content
        window.onclick = function(event) {
            if (event.target == document.getElementById('myModal')) {
                document.getElementById('myModal').style.display = 'none';
            }
        }
    </script>
</body>
</html>
